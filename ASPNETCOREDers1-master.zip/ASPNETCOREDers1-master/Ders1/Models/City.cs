﻿namespace Ders1.Models
{
    public class City
    {

        public string CityCode { get; set; } //PLAKA
        public string CityName { get; set; } 

    }
}
